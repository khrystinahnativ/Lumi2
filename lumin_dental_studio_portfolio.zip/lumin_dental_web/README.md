# Lumin Dental Studio — portfolio web

Jednostránkový responzivní web v češtině. Otevřete `index.html` v prohlížeči.

## Co obsahuje
- Úvodní sekci, nabídku služeb, představení studia, orientační ceník a kontakty
- Responzivní navigaci pro mobil
- Formulář s validací a ukázkovou potvrzovací zprávou
- CSS a JavaScript přímo v HTML, bez nutnosti instalace

## Před zveřejněním
- Nahraďte fiktivní adresu, telefon a e-mail skutečnými údaji.
- Ceník je pouze ilustrační; ověřte jej s klinikou.
- Formulář zatím nic neodesílá. Pro reálný provoz připojte backend / rezervační systém a doplňte odpovídající zásady ochrany osobních údajů.
- Fotografie a fonty se načítají z externích služeb (Unsplash a Google Fonts), proto je pro jejich zobrazení potřeba internet.

## Úpravy
Všechny texty, styly i skripty jsou v souboru `index.html`.
